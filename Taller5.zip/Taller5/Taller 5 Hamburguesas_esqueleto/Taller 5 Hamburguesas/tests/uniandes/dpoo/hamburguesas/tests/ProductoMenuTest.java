package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class ProductoMenuTest {

    private ProductoMenu producto;

    @BeforeEach
    public void setUp() {
        // Producto Inicial
        producto = new ProductoMenu("Hamburguesa", 10000);
    }

    @Test
    public void testGetNombre() {

        String nombre = producto.getNombre();

        assertEquals("Hamburguesa", nombre);
    }

    @Test
    public void testGetPrecio() {

        int precio = producto.getPrecio();

        assertEquals(10000, precio);
    }

    @Test
    public void testGenerarTextoFactura() {

        String texto = producto.generarTextoFactura();

        assertTrue(texto.contains("Hamburguesa"));
        assertTrue(texto.contains("10000"));
        assertFalse(texto.isEmpty());
    }
}