package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Files;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class PedidoTest {

    private Pedido pedido;
    private ProductoMenu p1;
    private ProductoMenu p2;

    @BeforeEach
    public void setUp() {
        pedido = new Pedido("Juan", "Calle 123");

        p1 = new ProductoMenu("Hamburguesa", 10000);
        p2 = new ProductoMenu("Papas", 5000);
    }

    @Test
    public void testNombreCliente() {

        String nombre = pedido.getNombreCliente();

        assertEquals("Juan", nombre);
    }

    @Test
    public void testAgregarProducto() {

        pedido.agregarProducto(p1);

        String factura = pedido.generarTextoFactura();

        assertTrue(factura.contains("Hamburguesa"));
    }

    @Test
    public void testCalculoPrecios() {

        pedido.agregarProducto(p1);
        pedido.agregarProducto(p2);

        int total = pedido.getPrecioTotalPedido();

        assertEquals(17850, total); // 15000 + 19%
    }

    @Test
    public void testGenerarTextoFactura() {

        pedido.agregarProducto(p1);

        String texto = pedido.generarTextoFactura();

        assertTrue(texto.contains("Juan"));
        assertTrue(texto.contains("Calle 123"));
        assertTrue(texto.contains("Hamburguesa"));
        assertTrue(texto.contains("Precio Neto"));
        assertTrue(texto.contains("IVA"));
        assertTrue(texto.contains("Precio Total"));
    }

    @Test
    public void testGuardarFactura() throws Exception {

        pedido.agregarProducto(p1);
        File archivo = new File("factura_test.txt");

        pedido.guardarFactura(archivo);

        assertTrue(archivo.exists());

        String contenido = new String(Files.readAllBytes(archivo.toPath()));
        assertTrue(contenido.contains("Juan"));

        archivo.delete();
    }
}