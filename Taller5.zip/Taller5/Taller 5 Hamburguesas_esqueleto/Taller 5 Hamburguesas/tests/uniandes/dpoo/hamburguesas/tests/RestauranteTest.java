package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.PrintWriter;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.excepciones.NoHayPedidoEnCursoException;
import uniandes.dpoo.hamburguesas.excepciones.YaHayUnPedidoEnCursoException;
import uniandes.dpoo.hamburguesas.mundo.Restaurante;

public class RestauranteTest {

    private Restaurante restaurante;

    @BeforeEach
    public void setUp() {
        restaurante = new Restaurante();

        File carpeta = new File("facturas");
        if (!carpeta.exists()) {
            carpeta.mkdir(); // crea la carpeta y si ya existe no hace nada
        }
    }

    @Test
    public void testIniciarPedido() throws YaHayUnPedidoEnCursoException {

        restaurante.iniciarPedido("Juan", "Calle 123");

        assertNotNull(restaurante.getPedidoEnCurso());
    }

    @Test
    public void testNoPermitirDosPedidos() throws YaHayUnPedidoEnCursoException {

        restaurante.iniciarPedido("Juan", "Calle 123");

        assertThrows(YaHayUnPedidoEnCursoException.class, () -> {
            restaurante.iniciarPedido("Pedro", "Otra");
        });
    }

    @Test
    public void testCerrarPedidoSinPedido() {

        assertThrows(NoHayPedidoEnCursoException.class, () -> {
            restaurante.cerrarYGuardarPedido();
        });
    }

    @Test
    public void testCerrarPedidoCorrectamente() throws Exception {

        restaurante.iniciarPedido("Juan", "Calle 123");

        restaurante.cerrarYGuardarPedido();

        assertNull(restaurante.getPedidoEnCurso());
    }

    @Test
    public void testCargarInformacion() throws Exception {

        restaurante.cargarInformacionRestaurante(
            new File("data/ingredientes.txt"),
            new File("data/menu.txt"),
            new File("data/combos.txt")
        );

        assertTrue(restaurante.getMenuBase().size() > 0);
        assertTrue(restaurante.getIngredientes().size() > 0);
        assertTrue(restaurante.getMenuCombos().size() > 0);
    }

    // verificar el if
    @Test
    public void testCarpetaYaExiste() {

        File carpeta = new File("facturas");
        carpeta.mkdir();

        if (!carpeta.exists()) {
            carpeta.mkdir();
        }

        assertTrue(carpeta.exists());
    }

    //ingrediente repetido
    @Test
    public void testIngredienteRepetido() throws Exception {

        File archivo = new File("ingredientes_test.txt");

        PrintWriter writer = new PrintWriter(archivo);
        writer.println("tomate;1000");
        writer.println("tomate;2000");
        writer.close();

        assertThrows(Exception.class, () -> {
            restaurante.cargarInformacionRestaurante(
                archivo,
                new File("data/menu.txt"),
                new File("data/combos.txt")
            );
        });

        archivo.delete();
    }

    //producto repetido
    @Test
    public void testProductoRepetido() throws Exception {

        File archivo = new File("menu_test.txt");

        PrintWriter writer = new PrintWriter(archivo);
        writer.println("Hamburguesa;10000");
        writer.println("Hamburguesa;12000");
        writer.close();

        assertThrows(Exception.class, () -> {
            restaurante.cargarInformacionRestaurante(
                new File("data/ingredientes.txt"),
                archivo,
                new File("data/combos.txt")
            );
        });

        archivo.delete();
    }

    // roducto faltante en combo
    @Test
    public void testProductoFaltanteEnCombo() throws Exception {

        File archivo = new File("combos_test.txt");

        PrintWriter writer = new PrintWriter(archivo);
        writer.println("Combo1;0.1;NoExiste");
        writer.close();

        assertThrows(Exception.class, () -> {
            restaurante.cargarInformacionRestaurante(
                new File("data/ingredientes.txt"),
                new File("data/menu.txt"),
                archivo
            );
        });

        archivo.delete();
    }

    
    @Test
    public void testComboValido() throws Exception {

        Restaurante restaurante2 = new Restaurante();

        // cargar info base
        restaurante2.cargarInformacionRestaurante(
            new File("data/ingredientes.txt"),
            new File("data/menu.txt"),
            new File("data/combos.txt")
        );
        
        // tomar producto real
        String nombreProducto = restaurante2.getMenuBase().get(0).getNombre();

        File archivo = new File("combos_test2.txt");

        PrintWriter writer = new PrintWriter(archivo);
        writer.println("Combo1;0.1;" + nombreProducto);
        writer.close();

        // usar un nuevo restaurante
        Restaurante restaurante3 = new Restaurante();

        restaurante3.cargarInformacionRestaurante(
            new File("data/ingredientes.txt"),
            new File("data/menu.txt"),
            archivo
        );

        assertTrue(restaurante3.getMenuCombos().size() > 0);

        archivo.delete();
    }
}	