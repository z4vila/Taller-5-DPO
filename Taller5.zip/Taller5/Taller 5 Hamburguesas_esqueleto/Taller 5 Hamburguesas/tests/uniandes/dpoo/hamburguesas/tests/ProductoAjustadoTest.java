package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Ingrediente;
import uniandes.dpoo.hamburguesas.mundo.ProductoAjustado;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class ProductoAjustadoTest {

    private ProductoMenu base;
    private ProductoAjustado ajustado;
    private Ingrediente queso;
    private Ingrediente tomate;

    @BeforeEach
    public void setUp() {
        // Estado Inicial
        base = new ProductoMenu("Hamburguesa", 10000);
        ajustado = new ProductoAjustado(base);

        queso = new Ingrediente("Queso", 2000);
        tomate = new Ingrediente("Tomate", 1000);
    }

    @Test
    public void testPrecioSinModificaciones() {

        int precio = ajustado.getPrecio();

        assertEquals(10000, precio);
    }

    @Test
    public void testAgregarIngredienteAumentaPrecio() {

        ajustado.agregarIngrediente(queso);

        int precio = ajustado.getPrecio();

        assertEquals(12000, precio);
    }

    @Test
    public void testQuitarIngredienteNoReducePrecio() {

        ajustado.eliminarIngrediente(tomate);

        int precio = ajustado.getPrecio();

        assertEquals(10000, precio);
    }

    @Test
    public void testGenerarTextoFactura() {

        ajustado.agregarIngrediente(queso);
        ajustado.eliminarIngrediente(tomate);

        String texto = ajustado.generarTextoFactura();

        assertTrue(texto.contains("Hamburguesa"));
        assertTrue(texto.contains("Queso"));
        assertTrue(texto.contains("Tomate"));
        assertTrue(texto.contains("12000"));
    }
}
