package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class ComboTest {

    private ProductoMenu p1;
    private ProductoMenu p2;
    private Combo combo;

    @BeforeEach
    public void setUp() {
    	// Estado Incial
        p1 = new ProductoMenu("Hamburguesa", 10000);
        p2 = new ProductoMenu("Papas", 5000);

        ArrayList<ProductoMenu> items = new ArrayList<>();
        items.add(p1);
        items.add(p2);

        combo = new Combo("Combo Especial", 0.1, items);
    }

    @Test
    public void testGetNombre() {

        String nombre = combo.getNombre();

        assertEquals("Combo Especial", nombre);
    }

    @Test
    public void testPrecioConDescuento() {

        int precio = combo.getPrecio();

        assertEquals(13500, precio); // 15000 - 10%
    }

    @Test
    public void testGenerarTextoFactura() {

        String texto = combo.generarTextoFactura();

        assertTrue(texto.contains("Combo Especial"));
        assertTrue(texto.contains("Hamburguesa"));
        assertTrue(texto.contains("Papas"));
        assertTrue(texto.contains("13500"));
    }
}